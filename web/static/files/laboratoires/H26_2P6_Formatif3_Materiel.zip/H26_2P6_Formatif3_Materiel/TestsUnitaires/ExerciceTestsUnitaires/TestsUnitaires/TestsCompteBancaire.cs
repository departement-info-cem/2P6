﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Modeles;

namespace TestsUnitaires
{
    /*     

    Écrire les tests unitaires MSTest pour CompteBancaire dans la classe TestsCompteBancaire.
    
    Rappels et indices:
        - Pour vérifier une exception : Assert.ThrowsException<ExceptionType>(() => instance.Methode(...));
        - Pour comparer décimaux : Assert.AreEqual(valeurAttendue, valeurObtenue);
        - Une valeur décimale doit être suffixée par 'm' (ex. 100m) pour indiquer qu'il s'agit d'un decimal.
        - Exécuter les tests via Test Explorer puis cliquer sur Run All.
        - Respecter Arrange–Agir–Assert pour que les tests restent compréhensibles.

    Complétez les méthodes de test suivantes en respectant les critères d’acceptation et en utilisant
    les bonnes pratiques de test unitaire (Arrange–Agir–Assert) :    

     */
    [TestClass]
    public sealed class TestsCompteBancaire
    {

        /// <summary>
        /// TODO 1 
        /// Vérifie que le dépôt d'un montant valide :
        ///     1) augmente correctement le solde du compte 
        ///     2) ajoute le bon nombre de transactions à l'historique
        ///     3) enregistre correctement l'entrée de transaction dans l'historique des transactions du compte
        /// 
        /// Rappel du format d'une entrée d'historique:
        /// <Date> | <Opération> | <Montant> | Solde: <SoldeAprèsTransaction>
        /// </summary>
        [TestMethod]
        public void Depot_MontantValide()
        {
            // Arranger

            // Agir

            // Auditer
        }

        /// <summary>
        /// TODO 2
        /// Vérifie que le dépôt d'un montant à zéro et un montant négatif lancent la bonne exception.
        /// </summary>
        [TestMethod]
        public void Depot_MontantInvalide()
        {
            // Arranger

            // Agir & Auditer
        }

        /// <summary>
        /// TODO 3 
        /// Vérifie que la propriété NbTransactions retourne le bon nombre de transactions.
        /// </summary>
        [TestMethod]
        public void NbTransactions_RetourneLeBonNombreDeTransactions()
        {
            // Arranger 

            // Agir & Auditer

            // Auditer 
        }

        /// <summary>
        /// TODO 4 
        /// Vérifie qu’un transfert avec un compte destination null
        /// déclenche une exception de type <see cref="ArgumentNullException"/>.
        /// </summary>
        /// <remarks>
        /// Ce test valide que la méthode <c>TransfertVers</c>
        /// refuse un compte destination invalide (null).
        /// </remarks>

        [TestMethod]
        public void TransfertVers_DestinationNull_ArgumentNullException()
        {
            // Arranger

            // Agir & Auditer

            

        }

        /// <summary> 
        /// TODO 5 
        /// Vérifie que le transfert de fonds entre deux comptes bancaires met à jour correctement les soldes des
        /// comptes source et destination, ainsi que l'historique des transactions.
        /// 
        /// Tester le cas positif seulement, en supposant que les validations d'entrée sont déjà testées dans les
        /// méthodes de dépôt et retrait.
        /// 
        /// Attention, la méthode TransfertVers utilise à la fois la méthode Retrait et la méthode Depot,
        /// donc il faut vérifier que toutes les entrées d'historique sont correctement enregistrées.
        /// </summary>
        [TestMethod]
        public void Transfert_TransfereLesFonds()
        {
            // Arranger 

            // Agir

            // Auditer source 

            // Auditer destination 
        }
    }
}
